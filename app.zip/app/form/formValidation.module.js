(function () {
    'use strict';

    angular.module('app.ui.form.validation', ['validation.match']);
})(); 